package backend;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ImageServer")
public class ImageServer extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String querry = request.getParameter("topic");
		
        CollageBuilder cb = new CollageBuilder();
        Collage collage = cb.buildCollage(querry);
        
        request.setAttribute("collageImage", collage.getImage());
        request.setAttribute("collageTitle", collage.getTitle());
        request.setAttribute("collageValid", collage.getDisplay());
        RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/displayPage.html");
        dispatch.forward(request, response);
    }
    
}
